# ITEM is TBD for now
# Here is the code I wrote down in python


