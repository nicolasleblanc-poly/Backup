@everywhere using LinearAlgebra, LinearAlgebra.BLAS, Distributed, FFTW, 
Printf, Base.Threads, MaxGParallelUtilities, MaxGStructs, MaxGBasisIntegrals, 
MaxGCirc, LinearAlgebra, MaxGCUDA, Random, MaxGOpr
### Setup of computation environment. 
# Set number of BLAS threads. The number of Julia threads is set as an 
# environment variable. The total number of threads is Julia threads + BLAS 
# threads. VICu is does not call BLAS libraries during threaded operations, 
# so both thread counts can be set near the available number of cores. 
threads = nthreads()
BLAS.set_num_threads(threads)
blasThreads = BLAS.get_num_threads()
println("MaxG test initialized with ", nthreads(), 
	" Julia threads and $blasThreads BLAS threads.")
# Define test volume, all lengths are defined relative to the wavelength. 
# Number of cells in the volume. 
cellsA = [16, 16, 16]
cellsB = [1, 1, 1]
# Edge lengths of a cell relative to the wavelength. 
scaleA = (0.02, 0.02, 0.02)
scaleB = (0.02, 0.02, 0.02)
# Center position of the volume. 
coordA = (0.0, 0.0, 0.0)
coordB = (-0.3, 0.0, 0.0)
# Create MaxG volumes.
volA = genMaxGVol(MaxGDom(cellsA, scaleA, coordA))
volB = genMaxGVol(MaxGDom(cellsB, scaleB, coordB))
# Information for Green function construction. 
# Complex frequency ratio. 
freqPhase = 1.0 + im * 0.0
# Gauss-Legendre approximation orders. 
ordGLIntFar = 2
ordGLIntMed = 8
ordGLIntNear = 16
# Cross over points for Gauss-Legendre approximation.
crossMedFar = 16
crossNearMed = 8
assemblyInfo = MaxGAssemblyOpts(freqPhase, ordGLIntFar, ordGLIntMed, 
	ordGLIntNear, crossMedFar, crossNearMed)
# Pre-allocate memory for circulant green function vector. 
greenCircAA = Array{ComplexF64}(undef, 3, 3, 2 * cellsA[1], 2 * cellsA[2], 
	2 * cellsA[3])
greenCircAB = Array{ComplexF64}(undef, 3, 3, cellsA[1] + cellsB[1],
	cellsA[2] + cellsB[2], cellsA[3], cellsB[3])
# CPU computation of Green function
genGreenSlf!(greenCircAA, volA, assemblyInfo)
genGreenExt!(greenCircAB, volA, volB, assemblyInfo)
### Prepare for operator construction.
## Pre-allocate memory 
# Fourier transform of the Green function, making use of real space symmetry 
# under transposition. Entries are xx, yy, zz, xy, xz, yz
# Self Green function
grnCFAA = Array{ComplexF64}(undef, 2 * cellsA[1], 2 * cellsA[2], 
	2 * cellsA[3], 6)
# Conjugate of the Fourier transform of the Green function
grnCFConjAA = Array{ComplexF64}(undef, 2 * cellsA[1], 2 * cellsA[2], 
	2 * cellsA[3], 6) # Sean put 9 for the last entry and I assume it is a mistake
	# because it would not be consistent with the other grnCF terms/values and 
	# what was in the code previously 
# External Green function
grnCFAB = Array{ComplexF64}(undef, cellsA[1] + cellsB[1], cellsA[2] + cellsB[2], 
	cellsA[3] + cellsB[3], 6)

## Self Green 
#  Work area on target side
currWrkEmbdAA = Array{ComplexF64}(undef, 8 * cellsA[1] * cellsA[2] * cellsA[3], 9)
# Embedded target 
currTrgEmbdAA = Array{ComplexF64}(undef, 8 * cellsA[1] * cellsA[2] * cellsA[3], 3)
# Embedded source memory
currSrcEmbdAA = Array{ComplexF64}(undef, 8 * cellsA[1] * cellsA[2] * cellsA[3], 3)
# Source current memory
currSrcAA = Array{ComplexF64}(undef, cellsA[1], cellsA[2], cellsA[3], 3)
# Target current memory
currTrgAA = Array{ComplexF64}(undef, cellsA[1], cellsA[2], cellsA[3], 3)
# ADJOINT
#  Work area on target side
cAdjWrkEmbdAA = Array{ComplexF64}(undef, 8 * cellsA[1] * cellsA[2] * cellsA[3], 9)
# Embedded target 
cAdjTrgEmbdAA = Array{ComplexF64}(undef, 8 * cellsA[1] * cellsA[2] * cellsA[3], 3)
# Embedded source memory
cAdjSrcEmbdAA = Array{ComplexF64}(undef, 8 * cellsA[1] * cellsA[2] * cellsA[3], 3)
# Source current memory
cAdjSrcAA = Array{ComplexF64}(undef, cellsA[1], cellsA[2], cellsA[3], 3)
# Target current memory
cAdjTrgAA = Array{ComplexF64}(undef, cellsA[1], cellsA[2], cellsA[3], 3)

## External Green
#  Work area on target side
currWrkEmbdAB = Array{ComplexF64}(undef, 8 * cellsA[1] * cellsA[2] * cellsA[3], 9)
# Embedded target 
currTrgEmbdAB = Array{ComplexF64}(undef, 8 * cellsA[1] * cellsA[2] * cellsA[3], 3)
# Embedded source memory
currSrcEmbdAB = Array{ComplexF64}(undef, 8 * cellsB[1] * cellsB[2] * cellsB[3], 3)
# Source current memory
currSrcAB = Array{ComplexF64}(undef, cellsB[1], cellsB[2], cellsB[3], 3)
# Target current memory
currTrgAB = Array{ComplexF64}(undef, cellsA[1], cellsA[2], cellsA[3], 3)

## Size settings for self Green function
srcSizeAA = (cellsA[1], cellsA[2], cellsA[3])
crcSizeAA = (2 * cellsA[1], 2 * cellsA[2], 2 * cellsA[3])
trgSizeAA = (cellsA[1], cellsA[2], cellsA[3])
## Size settings for external Green function
srcSizeAB = (cellsB[1], cellsB[2], cellsB[3])
crcSizeAB = (cellsA[1] + cellsB[1], cellsA[2] + cellsB[2], cellsA[3] + cellsB[3])
trgSizeAB = (cellsA[1], cellsA[2], cellsA[3])
# total cells 
totCellsAA = prod(srcSizeAA)
totCellsBB = prod(srcSizeAB)

## Plan in-place 3D Fast-Fourier transform
fftPlanFwdAA = plan_fft!(greenCircAA[1,1,:,:,:],(1,2,3))
fftPlanInvAA = plan_ifft!(greenCircAA[1,1,:,:,:],(1,2,3))
fftPlanFwdOutAA = plan_fft(greenCircAA[1,1,:,:,:],(1,2,3))

fftPlanFwdAB = plan_fft!(greenCircAB[1,1,:,:,:],(1,2,3))
fftPlanInvAB = plan_ifft!(greenCircAB[1,1,:,:,:],(1,2,3))
fftPlanFwdOutAB = plan_fft(greenCircAB[1,1,:,:,:],(1,2,3))

## Preform Fast-Fourier transforms of circulant Green functions
greenItr = 0
blockItr = 0

for colInd in 1 : 3, rowInd in 1 : colInd

	global blockItr = 3 * (colInd - 1) + rowInd
	global greenItr = blockGreenItr(blockItr)

	grnCFAA[:,:,:,greenItr] =  fftPlanFwdOutAA * greenCircAA[rowInd,colInd,:,:,:]
	grnCFAB[:,:,:,greenItr] =  fftPlanFwdOutAB * greenCircAB[rowInd,colInd,:,:,:]
end

### Declare operators
greenActAA! = () -> grnOpr!(fftPlanFwdAA, fftPlanInvAA, grnCFAA, trgSizeAA, 
	crcSizeAA, srcSizeAA, currTrgAA, currTrgEmbdAA, currWrkEmbdAA, 
	currSrcEmbdAA, currSrcAA)

greenAdjActAA! = () -> grnAdjOpr!(fftPlanFwdAA, fftPlanInvAA, grnCFAA, 
	trgSizeAA, crcSizeAA, srcSizeAA, cAdjTrgAA, cAdjTrgEmbdAA, cAdjWrkEmbdAA, 
	cAdjSrcEmbdAA, cAdjSrcAA)

greenActAB! = () -> grnOpr!(fftPlanFwdAB, fftPlanInvAB, grnCFAB, trgSizeAB, 
	crcSizeAB, srcSizeAB, currTrgAB, currTrgEmbdAB, currWrkEmbdAB, 
	currSrcEmbdAB, currSrcAB)

# Zero source current in preparation for use
for dirItr in 1 : 3
	
	for itrZ in 1 : srcSize[3], itrY in 1 : srcSize[2], itrX in 1 : srcSize[1]

		currSrc[itrX,itrY,itrZ,dirItr] = 0.0 + 0.0im
	end
end


# # Write full green function matrix from greenCirc. 
# function grnFull!()

# 	cellsX = cellsA[1]
# 	cellsY = cellsA[2]
# 	cellsZ = cellsA[3]
# 	totCells = prod(cellsA)

# 	overCountX = 0
# 	overCountY = 0
# 	overCountZ = 0

# 	### Create first three columns.
# 	# x-source
# 	greenFull[1 : totCells, 1] = reshape(greenCirc[1, 1, 1 : cellsX, 
# 		1 : cellsY, 1 : cellsZ], (totCells, 1))

# 	greenFull[(totCells + 1) : (2 * totCells), 1] = reshape(greenCirc[2, 1, 
# 		1 : cellsX, 1 : cellsY, 1 : cellsZ], (totCells, 1))

# 	greenFull[(2 * totCells + 1) : (3 * totCells), 1] = reshape(greenCirc[3, 1, 
# 		1 : cellsX, 1 : cellsY, 1 : cellsZ], (totCells, 1))
# 	# y-source
# 	greenFull[1 : totCells, 2] = reshape(greenCirc[1, 2, 1 : cellsX, 
# 		1 : cellsY, 1 : cellsZ], (totCells, 1))

# 	greenFull[(totCells + 1) : (2 * totCells), 2] = reshape(greenCirc[2, 2, 
# 		1 : cellsX, 1 : cellsY, 1 : cellsZ], (totCells, 1))

# 	greenFull[(2 * totCells + 1) : (3 * totCells), 2] = reshape(greenCirc[3, 2, 
# 		1 : cellsX, 1 : cellsY, 1 : cellsZ], (totCells, 1))
# 	# z-source
# 	greenFull[1 : totCells, 3] = reshape(greenCirc[1, 3, 1 : cellsX, 
# 		1 : cellsY, 1 : cellsZ], (totCells, 1))

# 	greenFull[(totCells + 1) : (2 * totCells), 3] = reshape(greenCirc[2, 3, 
# 		1 : cellsX, 1 : cellsY, 1 : cellsZ], (totCells, 1))

# 	greenFull[(2 * totCells + 1) : (3 * totCells), 3] = reshape(greenCirc[3, 3, 
# 		1 : cellsX, 1 : cellsY, 1 : cellsZ], (totCells, 1))

# 	### Create first three rows.
# 	greenFull[1 : totCells, 1]
# end
