module gmres
export GMRES_with_restart
using product, LinearAlgebra, vector
# based on the example code from https://tobydriscoll.net/fnc-julia/krylov/gmres.html
# code for the AA case 
i = 1

# check after the 20 iterations
# with 5 restarts 

# m is the maximum number of iterations
function GMRES_with_restart(l, b, cellsA, greenCircAA, chi_inv_coeff, P, m=20) # add cellsB for the BA case 
    n = length(b)
    # n = cellsA[1]*cellsA[2]*cellsA[3]*3
    print("n ", n, "\n")
    print("size(b) ", size(b), "\n")
    Q = zeros(ComplexF64,n,m+1)
    print(size(Q))
    # print("b ", b, "\n")
    Q[:,1] = reshape(b, (n,1))/norm(b)
    H = zeros(ComplexF64,m+1,m)
    # Initial solution is zero.
    x = 0
    residual = [norm(b);zeros(m)]
    for j in 1:m
        # print(size(Q[:,j]))

        # first G|v> type calculation
        # Need to change the reshape to get the cells used for greenCircBA
        cellsB = [1, 1, 1]

        v = asym_vect(greenCircAA, cellsA, chi_inv_coeff, l, P, reshape(Q[:,j],(cellsA[1], cellsA[2], cellsA[3], 3)))
        # output(l,Q[:,j],cellsA)
        # print("Q[:,j] ", Q[:,j], "\n")
        print(size(v),"\n")
        # print("v ", v, "\n")
        for i in 1:j
            H[i,j] = dot(Q[:,i],v)
            print(size(H[i,j]), "\n")
            print(size(Q[:,i]), "\n")

            v -= H[i,j]*Q[:,i]
            
        end
        
        H[j+1,j] = norm(v)
        Q[:,j+1] = v/H[j+1,j]
        # Solve the minimum residual problem.
        r = [norm(b); zeros(ComplexF64,j)]
        z = H[1:j+1,1:j] / r
        x = reshape(Q[:,1:j]*z,(cellsA[1],cellsA[2],cellsA[3],3))
        # second G|v> type calculation
        value = asym_vect(greenCircAA, cellsA, chi_inv_coeff, l, P, reshape(x,(cellsA[1], cellsA[2], cellsA[3], 3)))
        # output(l,x,cellsA)
        residual[j+1] = norm(value - b )
    end
    return x
end
end