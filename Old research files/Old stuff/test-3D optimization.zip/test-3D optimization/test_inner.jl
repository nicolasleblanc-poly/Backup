using G_v_product

