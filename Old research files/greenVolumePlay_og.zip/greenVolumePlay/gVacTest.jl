using LinearAlgebra, LinearAlgebra.BLAS, Distributed, FFTW
@everywhere using Printf, Base.Threads, MaxGParallelUtilities, MaxGStructs, 
MaxGBasisIntegrals, MaxGCirc, LinearAlgebra, MaxGCUDA
# Set number of BLAS threads. The number of Julia threads is set as an 
# environment variable. The total number of threads is Julia threads + BLAS 
# threads. VICu is does not call BLAS libraries during threaded operations, 
# so both thread counts can be set near the available number of cores. 
threads = nthreads()
BLAS.set_num_threads(threads)
blasThreads = BLAS.get_num_threads()
println("MaxG test initialized with ", nthreads(), 
	" Julia threads and $blasThreads BLAS threads.")
# Define test volume, all lengths are defined relative to the wavelength. 
# Number of cells in the volume. 
cellsA = [16, 16, 16]
cellsB = [1, 1, 1]
# Edge lengths of a cell relative to the wavelength. 
scaleA = (0.02, 0.02, 0.02)
scaleB = (0.02, 0.02, 0.02)
# Center position of the volume. 
coordA = (0.0, 0.0, 0.0)
coordB = (-0.3, 0.3, 0.0)
# Create MaxG volumes.
volA = genMaxGVol(MaxGDom(cellsA, scaleA, coordA))
volB = genMaxGVol(MaxGDom(cellsB, scaleB, coordB))
# Information for Green function construction. 
# Complex frequency ratio. 
freqPhase = 1.0 + im * 0.0
# Gauss-Legendre approximation orders. 
ordGLIntFar = 2
ordGLIntMed = 8
ordGLIntNear = 16
# Cross over points for Gauss-Legendre approximation.
crossMedFar = 16
crossNearMed = 8
assemblyInfo = MaxGAssemblyOpts(freqPhase, ordGLIntFar, ordGLIntMed, 
	ordGLIntNear, crossMedFar, crossNearMed)
# Pre-allocate memory for circulant green function vector. 
greenCircAA = Array{ComplexF64}(undef, 3, 3, 2 * cellsA[1], 2 * cellsA[2], 
	2 * cellsA[3])
greenCircBA = Array{ComplexF64}(undef, 3, 3, cellsB[1] + cellsA[1], cellsB[2] +
	cellsA[2], cellsB[3] + cellsA[3])
# CPU computation of Green function
genGreenSlf!(greenCircAA, volA, assemblyInfo)
genGreenExt!(greenCircBA, volB, volA, assemblyInfo)

### Eigenvalue test
include("eigTest.jl")

# Analytic test
# # separation vector
# s = 2 * pi * sqrt((coordB[1])^2 + coordB[2]^2 + coordB[3]^2)
# sh = (2 * pi) .* (coordB[1], coordB[2], coordB[3]) ./ s 
# # operators
# id = [1.0 0.0 0.0; 0.0 1.0 0.0; 0.0 0.0 1.0]
# sHs = [(sh[1] * sh[1]) (sh[1] * sh[2]) (sh[1] * sh[3]); 
# (sh[2] * sh[1]) (sh[2] * sh[2]) (sh[2] * sh[3]); 
# (sh[3] * sh[1]) (sh[3] * sh[2]) (sh[3] * sh[3])]
# # analytic green function
# gAna = (exp(im * s) / (4 * pi * s)) .* (((1 + (im * s - 1) / s^2) .* id) .- 
# ((1 + 3 * (im * s - 1) / s^2) .* sHs))

# conFac = 4.0314419358490252e-3 - 4.907076775369318e-12im

# ratio = (gAna ./ greenCircBA[:, :, 1, 1, 1]) .* (scale^3 / conFac)

return nothing;
# cudaLibPtr = libInitCu!()
# devNum = devCount(cudaLibPtr)
# print("Found ", devNum, " devices.\n")
# libFinlCu!(cudaLibPtr)
